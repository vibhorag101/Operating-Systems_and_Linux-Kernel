#include <stdio.h>
#include <stdlib.h>
int main()
{
    char num1[256];
    char num2[256];
    printf("enter the first string\n");
    scanf("%s",num1);
    printf("enter the second string\n");
    scanf("%s",num2);

    
    return 0;
}