#! /bin/bash
# The program prints the calendar for the whole month given a date
# The user pass the date dd mm yyyy fashion
MONTH=$2
YEAR=$3
cal $MONTH $YEAR
