void funcA();
void funcB(char binString[100]);
void funcC();
