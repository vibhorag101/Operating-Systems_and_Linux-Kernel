void funcA();
extern void funcB(char binString[100]);
extern void funcC();
extern void modifyStack();