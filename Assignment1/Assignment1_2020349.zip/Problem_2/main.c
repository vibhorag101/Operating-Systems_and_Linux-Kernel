#include <stdio.h>
#include <stdlib.h>
#include "function.h"
#include <string.h>
int main()
{
    printf("We are in main function now\n");
    funcA();
    return 0;
}